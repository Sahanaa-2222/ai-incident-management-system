async function load() {
    const res = await fetch("http://localhost:8080/api/incidents");
    const data = await res.json();
    document.getElementById("list").innerHTML =
        data.map(i => `<p>${i.id} - ${i.title} - ${i.status}</p>`).join("");
}

async function createIncident() {
    const title = document.getElementById("title").value;
    const description = document.getElementById("desc").value;
    const priority = document.getElementById("priority").value;

    await fetch("http://localhost:8080/api/incidents", {
        method: "POST",
        headers: {"Content-Type":"application/json"},
        body: JSON.stringify({
            title,
            description,
            priority,
            status: "OPEN"
        })
    });

    load();
}

load();
