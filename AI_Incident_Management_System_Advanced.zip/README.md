# AI-Powered Incident Management System

## Overview
The AI-Powered Incident Management System is an enterprise-style web application inspired by IT Service Management (ITSM) workflows. The project enables organizations to efficiently create, track, prioritize, and manage incidents through a secure and scalable architecture.

This project was developed using Java 17, Spring Boot, Spring Security, JWT Authentication, MySQL, Hibernate, REST APIs, HTML5, CSS3, and JavaScript.

---

## Features

- Incident Creation and Tracking
- Role-Based Access Control
- JWT Authentication & Authorization
- RESTful API Architecture
- Priority Classification
- Incident Lifecycle Management
- Responsive Frontend Dashboard
- MySQL Database Integration
- Layered Backend Architecture
- Real-Time Incident Monitoring

---

## Tech Stack

### Backend
- Java 17
- Spring Boot
- Spring Security
- Hibernate / JPA
- REST APIs

### Frontend
- HTML5
- CSS3
- JavaScript

### Database
- MySQL

### Tools
- Git & GitHub
- VS Code / IntelliJ IDEA
- XAMPP

---

## Project Structure

```bash
AI_Incident_Management_System/
│
├── backend/
│   └── src/main/java/com/cts/incidents/
│       ├── controller/
│       ├── service/
│       ├── repository/
│       ├── model/
│       └── IncidentManagementApplication.java
│
├── frontend/
│   ├── index.html
│   ├── style.css
│   └── app.js
│
├── db/
│   └── schema.sql
│
├── .gitignore
├── LICENSE
└── README.md
```

---

## API Endpoints

| Method | Endpoint | Description |
|--------|-----------|-------------|
| GET | /api/incidents | Get all incidents |
| POST | /api/incidents | Create incident |
| PUT | /api/incidents/{id} | Update incident |
| DELETE | /api/incidents/{id} | Delete incident |

---

## Database Schema

```sql
CREATE TABLE incidents (
    id INT PRIMARY KEY AUTO_INCREMENT,
    title VARCHAR(255),
    description TEXT,
    priority VARCHAR(50),
    status VARCHAR(50)
);
```

---

## How to Run

### Backend
1. Open backend project in IntelliJ IDEA or VS Code
2. Configure MySQL database
3. Run Spring Boot application

### Frontend
1. Open `frontend/index.html`
2. Ensure backend server is running on port `8080`

---

## Learning Outcomes

- Enterprise Java Backend Development
- REST API Integration
- Authentication using JWT
- Database Design using SQL
- Frontend-Backend Communication
- Responsive UI Development
- Incident Lifecycle Management

---

## Author

**Sahanaa Veeramani**

- GitHub: https://github.com/Sahanaa-2222
- LinkedIn: https://linkedin.com/in/sahanaa29

---

## License

This project is licensed under the MIT License.
