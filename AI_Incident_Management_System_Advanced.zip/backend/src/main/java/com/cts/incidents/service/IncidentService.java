package com.cts.incidents.service;

import com.cts.incidents.model.Incident;
import java.util.*;

public class IncidentService {

    private final Map<Integer, Incident> db = new HashMap<>();
    private int idCounter = 1;

    public List<Incident> getAll() {
        return new ArrayList<>(db.values());
    }

    public Incident create(Incident incident) {
        incident.setId(idCounter++);
        db.put(incident.getId(), incident);
        return incident;
    }

    public Incident update(int id, Incident updated) {
        updated.setId(id);
        db.put(id, updated);
        return updated;
    }

    public void delete(int id) {
        db.remove(id);
    }
}
