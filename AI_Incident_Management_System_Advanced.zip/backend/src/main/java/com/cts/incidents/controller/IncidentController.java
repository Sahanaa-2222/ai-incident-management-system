package com.cts.incidents.controller;

import com.cts.incidents.model.Incident;
import com.cts.incidents.service.IncidentService;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/incidents")
@CrossOrigin
public class IncidentController {

    private final IncidentService service = new IncidentService();

    @GetMapping
    public List<Incident> getAll() {
        return service.getAll();
    }

    @PostMapping
    public Incident create(@RequestBody Incident incident) {
        return service.create(incident);
    }

    @PutMapping("/{id}")
    public Incident update(@PathVariable int id, @RequestBody Incident incident) {
        return service.update(id, incident);
    }

    @DeleteMapping("/{id}")
    public String delete(@PathVariable int id) {
        service.delete(id);
        return "Deleted";
    }
}
