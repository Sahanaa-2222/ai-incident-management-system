package com.cts.incidents.repository;

// Placeholder for future JPA repository integration
public class IncidentRepository {
}
